import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types/user';
import { API_ENDPOINTS, apiRequest } from '../config/api';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, username: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  addToWatchlist: (animeId: string) => Promise<void>;
  removeFromWatchlist: (animeId: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Charger le profil utilisateur si un token existe
  useEffect(() => {
    const token = localStorage.getItem('authToken');
    if (token) {
      refreshProfile();
    }
  }, []);

  // Fonction pour se connecter
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const res = await apiRequest(API_ENDPOINTS.AUTH.LOGIN, {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      if (res.data?.token) {
        localStorage.setItem('authToken', res.data.token);
        await refreshProfile();
        setIsAuthenticated(true);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  // Fonction pour s’inscrire
  const register = async (email: string, password: string, username: string): Promise<boolean> => {
    try {
      const res = await apiRequest(API_ENDPOINTS.AUTH.REGISTER, {
        method: 'POST',
        body: JSON.stringify({ email, password, username })
      });
      if (res.data?.token) {
        localStorage.setItem('authToken', res.data.token);
        await refreshProfile();
        setIsAuthenticated(true);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  };

  // Fonction pour charger le profil utilisateur
  const refreshProfile = async () => {
    try {
      const res = await apiRequest(API_ENDPOINTS.USERS.PROFILE);
      setUser(res.data || null);
      setIsAuthenticated(!!res.data);
    } catch (err) {
      setUser(null);
      setIsAuthenticated(false);
      localStorage.removeItem('authToken');
    }
  };

  // Fonction pour se déconnecter
  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('authToken');
  };

  // Ajouter à la watchlist
  const addToWatchlist = async (animeId: string) => {
    try {
      await apiRequest(`${API_ENDPOINTS.USERS.WATCHLIST}/${animeId}`, { method: 'POST' });
      await refreshProfile();
    } catch (err) {
      // Optionnel : gestion d’erreur
    }
  };

  // Retirer de la watchlist
  const removeFromWatchlist = async (animeId: string) => {
    try {
      await apiRequest(`${API_ENDPOINTS.USERS.WATCHLIST}/${animeId}`, { method: 'DELETE' });
      await refreshProfile();
    } catch (err) {
      // Optionnel : gestion d’erreur
    }
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    isAuthenticated,
    addToWatchlist,
    removeFromWatchlist,
    refreshProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};