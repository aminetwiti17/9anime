// Service d'accès aux épisodes via l'API REST
const API_BASE = import.meta.env.VITE_API_URL || 'https://app.ty-dev.fr/api/v1';

export const episodeService = {
  // Récupérer les données d'un épisode par animeId et numéro d'épisode
  async getEpisodeData(animeId: string, episodeNumber: number) {
    try {
      const res = await fetch(`${API_BASE}/anime/${animeId}/episodes?number=${episodeNumber}`);
      if (!res.ok) return null;
      const data = await res.json();
      // Adaptez selon la structure de votre backend
      if (Array.isArray(data.data)) {
        return data.data.find((ep: any) => ep.episode_number === episodeNumber) || null;
      }
      return data.data || null;
    } catch (error) {
      console.error('Error fetching episode data:', error);
      return null;
    }
  },

  // Récupérer tous les épisodes d'un anime
  async getAnimeEpisodes(animeId: string) {
    try {
      const res = await fetch(`${API_BASE}/anime/${animeId}/episodes`);
      if (!res.ok) return null;
      const data = await res.json();
      return data.data || null;
    } catch (error) {
      console.error('Error fetching anime episodes:', error);
      return null;
    }
  },

  // Récupérer le titre d'un anime par son ID
  async getAnimeTitle(animeId: string) {
    try {
      const res = await fetch(`${API_BASE}/anime/${animeId}`);
      if (!res.ok) return null;
      const data = await res.json();
      return data.data?.title || null;
    } catch (error) {
      console.error('Error fetching anime title:', error);
      return null;
    }
  }
};