import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const testMongoDBConnection = async () => {
  try {
    console.log('🔍 Testing MongoDB connection...');
    
    const mongoURI = process.env.MONGODB_URI || 'mongodb://admin:admin123456@localhost:27017/anistream_db?authSource=admin';
    console.log(`📡 Connecting to: ${mongoURI.replace(/\/\/.*@/, '//***@')}`);
    
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000
    });

    console.log('✅ MongoDB connection successful!');
    console.log(`📊 Database: ${mongoose.connection.name}`);
    console.log(`🏠 Host: ${mongoose.connection.host}`);
    console.log(`🔌 Port: ${mongoose.connection.port}`);

    // Test database operations
    console.log('\n🧪 Testing database operations...');
    
    // Test collection creation
    const testCollection = mongoose.connection.db.collection('test_connection');
    await testCollection.insertOne({ test: true, timestamp: new Date() });
    console.log('✅ Collection creation test passed');
    
    // Test document retrieval
    const result = await testCollection.findOne({ test: true });
    console.log('✅ Document retrieval test passed');
    
    // Clean up test data
    await testCollection.deleteOne({ test: true });
    console.log('✅ Document deletion test passed');

    // Get database stats
    const stats = await mongoose.connection.db.stats();
    console.log('\n📊 Database Statistics:');
    console.log(`   Collections: ${stats.collections}`);
    console.log(`   Data Size: ${(stats.dataSize / 1024 / 1024).toFixed(2)} MB`);
    console.log(`   Storage Size: ${(stats.storageSize / 1024 / 1024).toFixed(2)} MB`);
    console.log(`   Indexes: ${stats.indexes}`);
    console.log(`   Index Size: ${(stats.indexSize / 1024 / 1024).toFixed(2)} MB`);

    await mongoose.connection.close();
    console.log('\n🎉 All tests passed! MongoDB is ready to use.');
    
  } catch (error) {
    console.error('❌ MongoDB connection test failed:', error.message);
    console.error('\n🔧 Troubleshooting tips:');
    console.error('1. Make sure MongoDB is running');
    console.error('2. Check your MONGODB_URI in .env file');
    console.error('3. Verify username/password if using authentication');
    console.error('4. Check if the database exists');
    console.error('5. Ensure network connectivity');
    
    process.exit(1);
  }
};

// Run the test
testMongoDBConnection(); 