import mongoose from 'mongoose';
import connectDB from '../config/database.js';
import dotenv from 'dotenv';

dotenv.config();

// Import models
import User from '../models/User.js';
import Anime from '../models/Anime.js';
import Episode from '../models/Episode.js';
import Genre from '../models/Genre.js';
import Studio from '../models/Studio.js';
import Season from '../models/Season.js';

// Function to run migrations
export const runMigrations = async () => {
  try {
    console.log('🔄 Starting MongoDB migrations...');

    // Connect to MongoDB
    await connectDB();

    // Check if collections exist and create them if needed
    await createCollections();
    
    // Create indexes
    await createIndexes();
    
    // Insert initial data
    await insertInitialData();

    console.log('✅ All MongoDB migrations completed successfully!');
  } catch (error) {
    console.error('❌ Migration failed:', error);
    throw error;
  }
};

// Create collections if they don't exist
const createCollections = async () => {
  console.log('📚 Creating collections...');
  
  const collections = [
    'users', 'anime', 'episodes', 'genres', 'studios', 
    'seasons', 'user_watchlists', 'user_watch_history'
  ];

  for (const collectionName of collections) {
    try {
      await mongoose.connection.db.createCollection(collectionName);
      console.log(`✅ Collection '${collectionName}' created`);
    } catch (error) {
      if (error.code === 48) { // Collection already exists
        console.log(`ℹ️ Collection '${collectionName}' already exists`);
      } else {
        console.error(`❌ Error creating collection '${collectionName}':`, error.message);
      }
    }
  }
};

// Create indexes for better performance
const createIndexes = async () => {
  console.log('🔍 Creating indexes...');

  try {
    // User indexes
    await User.collection.createIndex({ email: 1 }, { unique: true });
    await User.collection.createIndex({ username: 1 }, { unique: true });
    await User.collection.createIndex({ role: 1 });
    await User.collection.createIndex({ is_active: 1 });

    // Anime indexes
    await Anime.collection.createIndex({ slug: 1 }, { unique: true });
    await Anime.collection.createIndex({ status: 1 });
    await Anime.collection.createIndex({ anime_type: 1 });
    await Anime.collection.createIndex({ rating: -1 });
    await Anime.collection.createIndex({ view_count: -1 });
    await Anime.collection.createIndex({ is_trending: 1 });
    await Anime.collection.createIndex({ is_featured: 1 });
    await Anime.collection.createIndex({ release_year: -1 });
    await Anime.collection.createIndex({ genres: 1 });
    await Anime.collection.createIndex({ studio: 1 });

    // Episode indexes
    await Episode.collection.createIndex({ anime: 1, episode_number: 1 }, { unique: true });
    await Episode.collection.createIndex({ anime: 1 });
    await Episode.collection.createIndex({ air_date: -1 });
    await Episode.collection.createIndex({ is_available: 1 });

    // Genre indexes
    await Genre.collection.createIndex({ name: 1 }, { unique: true });

    // Studio indexes
    await Studio.collection.createIndex({ name: 1 }, { unique: true });

    // Text search indexes
    await Anime.collection.createIndex({
      title: 'text',
      english_title: 'text',
      japanese_title: 'text',
      description: 'text'
    });

    console.log('✅ All indexes created successfully');
  } catch (error) {
    console.error('❌ Error creating indexes:', error);
  }
};

// Insert initial data
const insertInitialData = async () => {
  console.log('🌱 Inserting initial data...');

  try {
    // Check if genres already exist
    const existingGenres = await Genre.countDocuments();
    if (existingGenres === 0) {
      const genres = [
        { name: 'Action', description: 'Anime with intense action sequences', color: '#ef4444' },
        { name: 'Adventure', description: 'Journey and exploration themed anime', color: '#f59e0b' },
        { name: 'Comedy', description: 'Humorous and light-hearted anime', color: '#10b981' },
        { name: 'Drama', description: 'Serious and emotional storytelling', color: '#8b5cf6' },
        { name: 'Fantasy', description: 'Supernatural and magical elements', color: '#06b6d4' },
        { name: 'Horror', description: 'Scary and suspenseful content', color: '#dc2626' },
        { name: 'Mystery', description: 'Puzzle-solving and detective stories', color: '#7c3aed' },
        { name: 'Romance', description: 'Love and relationship stories', color: '#ec4899' },
        { name: 'Sci-Fi', description: 'Science fiction and futuristic themes', color: '#6366f1' },
        { name: 'Slice of Life', description: 'Everyday life and realistic situations', color: '#84cc16' },
        { name: 'Sports', description: 'Athletic and competitive themes', color: '#f97316' },
        { name: 'Supernatural', description: 'Paranormal and mystical elements', color: '#a855f7' },
        { name: 'Thriller', description: 'Suspenseful and intense narratives', color: '#64748b' }
      ];

      await Genre.insertMany(genres);
      console.log('✅ Initial genres inserted');
    } else {
      console.log('ℹ️ Genres already exist, skipping...');
    }

    // Check if studios already exist
    const existingStudios = await Studio.countDocuments();
    if (existingStudios === 0) {
      const studios = [
        { name: 'MAPPA', description: 'Modern Animation Planning Project', founded_year: 2011 },
        { name: 'Studio Ghibli', description: 'Famous animation studio', founded_year: 1985 },
        { name: 'Bones', description: 'Bones Inc.', founded_year: 1998 },
        { name: 'Madhouse', description: 'Madhouse Inc.', founded_year: 1972 },
        { name: 'A-1 Pictures', description: 'A-1 Pictures Inc.', founded_year: 2005 },
        { name: 'Production I.G', description: 'Production I.G Inc.', founded_year: 1987 },
        { name: 'Kyoto Animation', description: 'Kyoto Animation Co., Ltd.', founded_year: 1981 },
        { name: 'Trigger', description: 'Studio Trigger', founded_year: 2011 }
      ];

      await Studio.insertMany(studios);
      console.log('✅ Initial studios inserted');
    } else {
      console.log('ℹ️ Studios already exist, skipping...');
    }

    // Check if seasons already exist
    const existingSeasons = await Season.countDocuments();
    if (existingSeasons === 0) {
      const currentYear = new Date().getFullYear();
      const seasons = [
        { name: 'Spring', year: currentYear, season_type: 'Spring' },
        { name: 'Summer', year: currentYear, season_type: 'Summer' },
        { name: 'Fall', year: currentYear, season_type: 'Fall' },
        { name: 'Winter', year: currentYear, season_type: 'Winter' }
      ];

      await Season.insertMany(seasons);
      console.log('✅ Initial seasons inserted');
    } else {
      console.log('ℹ️ Seasons already exist, skipping...');
    }

    console.log('✅ All initial data inserted successfully');
  } catch (error) {
    console.error('❌ Error inserting initial data:', error);
  }
};

// Run migrations if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runMigrations()
    .then(() => {
      console.log('🎉 Migration completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Migration failed:', error);
      process.exit(1);
    });
}