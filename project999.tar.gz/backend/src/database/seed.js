import mongoose from 'mongoose';
import connectDB from '../config/database.js';
import dotenv from 'dotenv';

dotenv.config();

// Import models
import User from '../models/User.js';
import Anime from '../models/Anime.js';
import Episode from '../models/Episode.js';
import Genre from '../models/Genre.js';
import Studio from '../models/Studio.js';
import Season from '../models/Season.js';

// Sample data
const sampleGenres = [
  { name: 'Action', description: 'Anime with intense action sequences', color: '#ef4444' },
  { name: 'Adventure', description: 'Journey and exploration themed anime', color: '#f59e0b' },
  { name: 'Comedy', description: 'Humorous and light-hearted anime', color: '#10b981' },
  { name: 'Drama', description: 'Serious and emotional storytelling', color: '#8b5cf6' },
  { name: 'Fantasy', description: 'Supernatural and magical elements', color: '#06b6d4' },
  { name: 'Horror', description: 'Scary and suspenseful content', color: '#dc2626' },
  { name: 'Mystery', description: 'Puzzle-solving and detective stories', color: '#7c3aed' },
  { name: 'Romance', description: 'Love and relationship stories', color: '#ec4899' },
  { name: 'Sci-Fi', description: 'Science fiction and futuristic themes', color: '#6366f1' },
  { name: 'Slice of Life', description: 'Everyday life and realistic situations', color: '#84cc16' },
  { name: 'Sports', description: 'Athletic and competitive themes', color: '#f97316' },
  { name: 'Supernatural', description: 'Paranormal and mystical elements', color: '#a855f7' },
  { name: 'Thriller', description: 'Suspenseful and intense narratives', color: '#64748b' }
];

const sampleStudios = [
  { name: 'MAPPA', description: 'Modern Animation Planning Project', founded_year: 2011 },
  { name: 'Studio Ghibli', description: 'Famous animation studio', founded_year: 1985 },
  { name: 'Bones', description: 'Bones Inc.', founded_year: 1998 },
  { name: 'Madhouse', description: 'Madhouse Inc.', founded_year: 1972 },
  { name: 'A-1 Pictures', description: 'A-1 Pictures Inc.', founded_year: 2005 },
  { name: 'Production I.G', description: 'Production I.G Inc.', founded_year: 1987 },
  { name: 'Kyoto Animation', description: 'Kyoto Animation Co., Ltd.', founded_year: 1981 },
  { name: 'Trigger', description: 'Studio Trigger', founded_year: 2011 }
];

const sampleAnime = [
  {
    title: 'Attack on Titan',
    english_title: 'Attack on Titan',
    japanese_title: '進撃の巨人',
    slug: 'attack-on-titan',
    description: 'Humanity fights for survival against giant humanoid Titans in this epic story of courage, sacrifice, and the will to survive.',
    synopsis: 'Centuries ago, mankind was slaughtered to near extinction by monstrous humanoid creatures called Titans, forcing humans to hide in fear behind enormous concentric walls. What makes these giants truly terrifying is that their taste for human flesh is not born out of hunger but what appears to be out of pleasure.',
    poster_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=1200',
    anime_type: 'TV',
    status: 'completed',
    rating: 9.0,
    popularity_score: 95,
    total_episodes: 75,
    episode_duration: 24,
    start_date: new Date('2013-04-07'),
    end_date: new Date('2023-11-05'),
    release_year: 2013,
    source_material: 'Manga',
    age_rating: 'R+',
    is_featured: true,
    is_trending: true,
    view_count: 15000000,
    meta_title: 'Attack on Titan - Epic Anime Series',
    meta_description: 'Watch Attack on Titan online. Humanity fights for survival against giant Titans in this epic anime series.',
    keywords: ['attack on titan', 'shingeki no kyojin', 'anime', 'action', 'drama']
  },
  {
    title: 'Demon Slayer',
    english_title: 'Demon Slayer: Kimetsu no Yaiba',
    japanese_title: '鬼滅の刃',
    slug: 'demon-slayer',
    description: 'A young boy becomes a demon slayer to save his sister and avenge his family.',
    synopsis: 'Tanjirou Kamado, a kind-hearted teenager who sells charcoal for a living, finds his family slaughtered by a demon. To make matters worse, his younger sister Nezuko, the sole survivor, has been transformed into a demon herself.',
    poster_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=1200',
    anime_type: 'TV',
    status: 'ongoing',
    rating: 8.9,
    popularity_score: 98,
    total_episodes: 44,
    episode_duration: 24,
    start_date: new Date('2019-04-06'),
    release_year: 2019,
    source_material: 'Manga',
    age_rating: 'R+',
    is_featured: true,
    is_trending: true,
    view_count: 12000000,
    meta_title: 'Demon Slayer - Kimetsu no Yaiba',
    meta_description: 'Watch Demon Slayer online. A young boy becomes a demon slayer to save his sister.',
    keywords: ['demon slayer', 'kimetsu no yaiba', 'anime', 'action', 'fantasy']
  },
  {
    title: 'My Hero Academia',
    english_title: 'My Hero Academia',
    japanese_title: '僕のヒーローアカデミア',
    slug: 'my-hero-academia',
    description: 'In a world where people with superpowers are the norm, a boy without powers dreams of becoming a hero.',
    synopsis: 'Izuku Midoriya, a boy born without superpowers in a world where they have become commonplace, but who still dreams of becoming a hero himself.',
    poster_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=400',
    banner_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=1200',
    anime_type: 'TV',
    status: 'ongoing',
    rating: 8.5,
    popularity_score: 92,
    total_episodes: 138,
    episode_duration: 24,
    start_date: new Date('2016-04-03'),
    release_year: 2016,
    source_material: 'Manga',
    age_rating: 'PG-13',
    is_featured: true,
    is_trending: false,
    view_count: 8000000,
    meta_title: 'My Hero Academia - Superhero Anime',
    meta_description: 'Watch My Hero Academia online. A boy without powers dreams of becoming a hero.',
    keywords: ['my hero academia', 'boku no hero academia', 'anime', 'superhero', 'action']
  }
];

// Function to seed database
export const seedDatabase = async () => {
  try {
    console.log('🌱 Starting database seeding...');

    // Connect to MongoDB
    await connectDB();

    // Clear existing data
    console.log('🧹 Clearing existing data...');
    await User.deleteMany({});
    await Anime.deleteMany({});
    await Episode.deleteMany({});
    await Genre.deleteMany({});
    await Studio.deleteMany({});
    await Season.deleteMany({});

    // Insert genres
    console.log('📚 Inserting genres...');
    const insertedGenres = await Genre.insertMany(sampleGenres);
    console.log(`✅ ${insertedGenres.length} genres inserted`);

    // Insert studios
    console.log('🎬 Inserting studios...');
    const insertedStudios = await Studio.insertMany(sampleStudios);
    console.log(`✅ ${insertedStudios.length} studios inserted`);

    // Insert seasons
    console.log('🍂 Inserting seasons...');
    const currentYear = new Date().getFullYear();
    const seasons = [
      { name: 'Spring', year: currentYear, season_type: 'Spring' },
      { name: 'Summer', year: currentYear, season_type: 'Summer' },
      { name: 'Fall', year: currentYear, season_type: 'Fall' },
      { name: 'Winter', year: currentYear, season_type: 'Winter' }
    ];
    const insertedSeasons = await Season.insertMany(seasons);
    console.log(`✅ ${insertedSeasons.length} seasons inserted`);

    // Get references for relationships
    const actionGenre = await Genre.findOne({ name: 'Action' });
    const adventureGenre = await Genre.findOne({ name: 'Adventure' });
    const dramaGenre = await Genre.findOne({ name: 'Drama' });
    const fantasyGenre = await Genre.findOne({ name: 'Fantasy' });
    const mappaStudio = await Studio.findOne({ name: 'MAPPA' });
    const bonesStudio = await Studio.findOne({ name: 'Bones' });
    const currentSeason = await Season.findOne({ name: 'Spring', year: currentYear });

    // Insert anime with proper references
    console.log('🎌 Inserting anime...');
    const animeWithRefs = sampleAnime.map(anime => ({
      ...anime,
      genres: [actionGenre._id, adventureGenre._id, dramaGenre._id],
      studio: mappaStudio._id,
      season: currentSeason._id
    }));

    const insertedAnime = await Anime.insertMany(animeWithRefs);
    console.log(`✅ ${insertedAnime.length} anime inserted`);

    // Insert episodes for each anime
    // console.log('📺 Inserting episodes...');
    // let episodeCount = 0;
    
    // for (const anime of insertedAnime) {
    //   const episodes = [];
    //   for (let i = 1; i <= Math.min(anime.total_episodes, 5); i++) {
    //     episodes.push({
    //       anime: anime._id,
    //       episode_number: i,
    //       title: `Episode ${i}`,
    //       description: `Episode ${i} of ${anime.title}`,
    //       thumbnail_url: anime.poster_url,
    //       duration: anime.episode_duration,
    //       air_date: new Date(anime.start_date.getTime() + (i - 1) * 7 * 24 * 60 * 60 * 1000),
    //       is_filler: false,
    //       is_recap: false,
    //       is_available: true,
    //       subtitle_type: 'SUB',
    //       view_count: Math.floor(Math.random() * 100000),
    //       video_sources: [
    //         {
    //           server_name: 'Server 1',
    //           server_location: 'US',
    //           quality: '1080p',
    //           subtitle_type: 'SUB',
    //           video_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
    //           embed_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
    //           is_active: true,
    //           priority: 1
    //         },
    //         {
    //           server_name: 'Server 2',
    //           server_location: 'EU',
    //           quality: '720p',
    //           subtitle_type: 'SUB',
    //           video_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
    //           embed_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
    //           is_active: true,
    //           priority: 2
    //         }
    //       ]
    //     });
    //   }
      
    //   const insertedEpisodes = await Episode.insertMany(episodes);
    //   episodeCount += insertedEpisodes.length;
    // }
    
    // console.log(`✅ ${episodeCount} episodes inserted`);

    // Insert sample users
    console.log('👥 Inserting sample users...');
    const sampleUsers = [
      {
        email: 'admin@anistream.com',
        username: 'admin',
        password: '$2b$10$e1dcx3SkE/7TzZLhVtFp/uviQVWV9dLp5fID7XItgEMtYB7juT2Na',
        role: 'admin',
        is_active: true,
        email_verified: true
      },
      {
        email: 'user@anistream.com',
        username: 'user',
        password: '$2b$10$e1dcx3SkE/7TzZLhVtFp/uviQVWV9dLp5fID7XItgEMtYB7juT2Na',
        role: 'user',
        is_active: true,
        email_verified: true
      }
    ];

    const insertedUsers = await User.insertMany(sampleUsers);
    console.log(`✅ ${insertedUsers.length} users inserted`);

    console.log('🎉 Database seeding completed successfully!');
    console.log(`📊 Summary:`);
    console.log(`   - ${insertedGenres.length} genres`);
    console.log(`   - ${insertedStudios.length} studios`);
    console.log(`   - ${insertedSeasons.length} seasons`);
    console.log(`   - ${insertedAnime.length} anime`);
    // console.log(`   - ${episodeCount} episodes`);
    console.log(`   - ${insertedUsers.length} users`);

  } catch (error) {
    console.error('❌ Seeding failed:', error);
    throw error;
  }
};

// Run seeding if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log('🎉 Seeding completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Seeding failed:', error);
      process.exit(1);
    });
}