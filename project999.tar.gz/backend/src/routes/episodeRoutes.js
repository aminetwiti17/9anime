import express from 'express';
import Episode from '../models/Episode.js';
import Anime from '../models/Anime.js';
import { asyncHandler } from '../middleware/errorMiddleware.js';

const router = express.Router();

// @route   GET /api/v1/episodes/latest
// @desc    Get latest episodes
// @access  Public
router.get('/latest', asyncHandler(async (req, res) => {
  const { limit = 20 } = req.query;
  
  const episodes = await Episode.find({ is_available: true })
    .populate('anime', 'title poster_url slug')
    .sort({ air_date: -1, createdAt: -1 })
    .limit(parseInt(limit));

  res.json({
    success: true,
    message: 'Latest episodes retrieved successfully',
    data: episodes,
    count: episodes.length
  });
}));

// @route   GET /api/v1/episodes/:id
// @desc    Get episode by ID
// @access  Public
router.get('/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;
  
  const episode = await Episode.findById(id)
    .populate('anime', 'title poster_url slug');

  if (!episode) {
    return res.status(404).json({
      success: false,
      message: 'Episode not found'
    });
  }

  // Increment view count
  episode.view_count += 1;
  await episode.save();

  res.json({
    success: true,
    message: 'Episode retrieved successfully',
    data: episode
  });
}));

// @route   GET /api/v1/episodes/anime/:animeId
// @desc    Get episodes by anime ID
// @access  Public
router.get('/anime/:animeId', asyncHandler(async (req, res) => {
  const { animeId } = req.params;
  const { page = 1, limit = 50 } = req.query;

  // Find anime first
  const anime = await Anime.findOne({ 
    $or: [{ _id: animeId }, { slug: animeId }] 
  });

  if (!anime) {
    return res.status(404).json({
      success: false,
      message: 'Anime not found'
    });
  }

  // Get episodes
  const skip = (page - 1) * limit;
  const episodes = await Episode.find({ anime: anime._id })
    .populate('anime', 'title poster_url slug')
    .sort({ episode_number: 1 })
    .skip(skip)
    .limit(parseInt(limit));

  const total = await Episode.countDocuments({ anime: anime._id });

  res.json({
    success: true,
    message: 'Episodes retrieved successfully',
    data: episodes,
    pagination: {
      current_page: parseInt(page),
      per_page: parseInt(limit),
      total,
      total_pages: Math.ceil(total / limit)
    }
  });
}));

// @route   GET /api/v1/episodes/anime/:animeId/episode/:episodeNumber
// @desc    Get specific episode by anime ID and episode number
// @access  Public
router.get('/anime/:animeId/episode/:episodeNumber', asyncHandler(async (req, res) => {
  const { animeId, episodeNumber } = req.params;

  // Find anime first
  const anime = await Anime.findOne({ 
    $or: [{ _id: animeId }, { slug: animeId }] 
  });

  if (!anime) {
    return res.status(404).json({
      success: false,
      message: 'Anime not found'
    });
  }

  // Find episode
  const episode = await Episode.findOne({ 
    anime: anime._id, 
    episode_number: parseInt(episodeNumber) 
  }).populate('anime', 'title poster_url slug');

  if (!episode) {
    return res.status(404).json({
      success: false,
      message: 'Episode not found'
    });
  }

  // Increment view count
  episode.view_count += 1;
  await episode.save();

  res.json({
    success: true,
    message: 'Episode retrieved successfully',
    data: episode
  });
}));

// @route   POST /api/v1/episodes
// @desc    Create new episode (Admin only)
// @access  Private/Admin
router.post('/', asyncHandler(async (req, res) => {
  const episode = new Episode(req.body);
  await episode.save();

  await episode.populate('anime', 'title poster_url slug');

  res.status(201).json({
    success: true,
    message: 'Episode created successfully',
    data: episode
  });
}));

export default router;