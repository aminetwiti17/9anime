import express from 'express';

const router = express.Router();

// Mock search data (in production, use database with full-text search)
const searchableAnime = [
  {
    id: '1',
    title: 'Attack on Titan',
    english_title: 'Attack on Titan',
    japanese_title: '進撃の巨人',
    slug: 'attack-on-titan',
    description: 'Humanity fights for survival against giant humanoid Titans',
    poster_url: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 9.0,
    release_year: 2013,
    anime_type: 'TV',
    status: 'completed',
    genres: ['Action', 'Drama', 'Fantasy']
  },
  {
    id: '2',
    title: 'Demon Slayer',
    english_title: 'Demon Slayer: Kimetsu no Yaiba',
    japanese_title: '鬼滅の刃',
    slug: 'demon-slayer',
    description: 'A young boy becomes a demon slayer to save his sister',
    poster_url: 'https://images.pexels.com/photos/1566837/pexels-photo-1566837.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 8.7,
    release_year: 2019,
    anime_type: 'TV',
    status: 'ongoing',
    genres: ['Action', 'Supernatural', 'Historical']
  }
];

// @route   GET /api/v1/search
// @desc    Search anime
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      q = '',
      genre,
      year,
      type,
      status,
      sort = 'relevance',
      page = 1,
      limit = 20
    } = req.query;

    let results = [...searchableAnime];

    // Text search
    if (q) {
      const query = q.toLowerCase();
      results = results.filter(anime =>
        anime.title.toLowerCase().includes(query) ||
        anime.english_title?.toLowerCase().includes(query) ||
        anime.japanese_title?.toLowerCase().includes(query) ||
        anime.description.toLowerCase().includes(query) ||
        anime.genres.some(g => g.toLowerCase().includes(query))
      );
    }

    // Apply filters
    if (genre) {
      results = results.filter(anime =>
        anime.genres.some(g => g.toLowerCase() === genre.toLowerCase())
      );
    }

    if (year) {
      results = results.filter(anime => anime.release_year === parseInt(year));
    }

    if (type) {
      results = results.filter(anime => anime.anime_type === type);
    }

    if (status) {
      results = results.filter(anime => anime.status === status);
    }

    // Apply sorting
    switch (sort) {
      case 'title':
        results.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'year':
        results.sort((a, b) => b.release_year - a.release_year);
        break;
      case 'rating':
        results.sort((a, b) => b.rating - a.rating);
        break;
      default:
        // Relevance sorting (by rating for now)
        results.sort((a, b) => b.rating - a.rating);
    }

    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedResults = results.slice(startIndex, endIndex);

    res.json({
      success: true,
      message: 'Search completed successfully',
      data: paginatedResults,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: results.length,
        total_pages: Math.ceil(results.length / limit)
      },
      filters: {
        query: q,
        genre,
        year,
        type,
        status,
        sort
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   GET /api/v1/search/suggestions
// @desc    Get search suggestions
// @access  Public
router.get('/suggestions', async (req, res) => {
  try {
    const { q = '' } = req.query;

    if (!q || q.length < 2) {
      return res.json({
        success: true,
        message: 'Suggestions retrieved successfully',
        data: []
      });
    }

    const query = q.toLowerCase();
    const suggestions = searchableAnime
      .filter(anime =>
        anime.title.toLowerCase().includes(query) ||
        anime.english_title?.toLowerCase().includes(query)
      )
      .slice(0, 5)
      .map(anime => ({
        id: anime.id,
        title: anime.title,
        poster_url: anime.poster_url,
        rating: anime.rating,
        year: anime.release_year
      }));

    res.json({
      success: true,
      message: 'Suggestions retrieved successfully',
      data: suggestions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   GET /api/v1/search/trending
// @desc    Get trending search terms
// @access  Public
router.get('/trending', async (req, res) => {
  try {
    const trendingTerms = [
      'Attack on Titan',
      'Demon Slayer',
      'One Piece',
      'Naruto',
      'Jujutsu Kaisen',
      'My Hero Academia'
    ];

    res.json({
      success: true,
      message: 'Trending searches retrieved successfully',
      data: trendingTerms
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

export default router;