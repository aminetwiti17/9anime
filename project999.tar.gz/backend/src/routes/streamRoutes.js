import express from 'express';

const router = express.Router();

// @route   GET /api/v1/stream/episode/:episodeId
// @desc    Get streaming sources for episode
// @access  Public
router.get('/episode/:episodeId', async (req, res) => {
  try {
    const { episodeId } = req.params;

    // Mock streaming sources
    const sources = [
      {
        id: '1',
        server_name: 'Server 1',
        server_location: 'US',
        quality: '1080p',
        subtitle_type: 'SUB',
        video_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
        embed_url: null,
        is_active: true,
        priority: 1,
        avg_load_time: 2.5,
        uptime_percentage: 99.5
      },
      {
        id: '2',
        server_name: 'Server 2',
        server_location: 'EU',
        quality: '720p',
        subtitle_type: 'SUB',
        video_url: 'https://sample-videos.com/zip/10/mp4/mp4-sample-video.mp4',
        embed_url: null,
        is_active: true,
        priority: 2,
        avg_load_time: 3.0,
        uptime_percentage: 98.0
      }
    ];

    res.json({
      success: true,
      message: 'Streaming sources retrieved successfully',
      data: sources,
      count: sources.length
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   POST /api/v1/stream/report
// @desc    Report streaming issue
// @access  Public
router.post('/report', async (req, res) => {
  try {
    const { episode_id, source_id, issue_type, description } = req.body;

    // In production, save to database
    const report = {
      id: Date.now().toString(),
      episode_id,
      source_id,
      issue_type,
      description,
      reported_at: new Date().toISOString(),
      status: 'pending'
    };

    res.status(201).json({
      success: true,
      message: 'Issue reported successfully',
      data: report
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

export default router;