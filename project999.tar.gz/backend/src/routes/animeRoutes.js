import express from 'express';
import Anime from '../models/Anime.js';
import Episode from '../models/Episode.js';
import Genre from '../models/Genre.js';
import Studio from '../models/Studio.js';
import Season from '../models/Season.js';
import { asyncHandler } from '../middleware/errorMiddleware.js';

const router = express.Router();

// @route   GET /api/v1/anime
// @desc    Get all anime with pagination and filters
// @access  Public
router.get('/', asyncHandler(async (req, res) => {
  const {
    page = 1,
    limit = 20,
    genre,
    status,
    type,
    year,
    sort = 'rating',
    order = 'desc',
    search
  } = req.query;

  // Build query
  let query = {};

  if (genre) {
    const genreDoc = await Genre.findOne({ name: new RegExp(genre, 'i') });
    if (genreDoc) {
      query.genres = genreDoc._id;
    }
  }

  if (status) {
    query.status = status;
  }

  if (type) {
    query.anime_type = type;
  }

  if (year) {
    query.release_year = parseInt(year);
  }

  if (search) {
    query.$text = { $search: search };
  }

  // Build sort
  const sortOrder = order === 'desc' ? -1 : 1;
  const sortObj = { [sort]: sortOrder };

  // Execute query with pagination
  const skip = (page - 1) * limit;
  const anime = await Anime.find(query)
    .populate('genres', 'name color')
    .populate('studio', 'name')
    .populate('season', 'name year season_type')
    .sort(sortObj)
    .skip(skip)
    .limit(parseInt(limit));

  const total = await Anime.countDocuments(query);

  res.json({
    success: true,
    message: 'Anime retrieved successfully',
    data: anime,
    pagination: {
      current_page: parseInt(page),
      per_page: parseInt(limit),
      total,
      total_pages: Math.ceil(total / limit)
    }
  });
}));

// @route   GET /api/v1/anime/trending
// @desc    Get trending anime
// @access  Public
router.get('/trending', asyncHandler(async (req, res) => {
  const { limit = 10 } = req.query;

  const trendingAnime = await Anime.find({ is_trending: true })
    .populate('genres', 'name color')
    .populate('studio', 'name')
    .sort({ popularity_score: -1, view_count: -1 })
    .limit(parseInt(limit));

  res.json({
    success: true,
    message: 'Trending anime retrieved successfully',
    data: trendingAnime
  });
}));

// @route   GET /api/v1/anime/featured
// @desc    Get featured anime
// @access  Public
router.get('/featured', asyncHandler(async (req, res) => {
  const { limit = 10 } = req.query;

  const featuredAnime = await Anime.find({ is_featured: true })
    .populate('genres', 'name color')
    .populate('studio', 'name')
    .sort({ rating: -1 })
    .limit(parseInt(limit));

  res.json({
    success: true,
    message: 'Featured anime retrieved successfully',
    data: featuredAnime
  });
}));

// @route   GET /api/v1/anime/:slug
// @desc    Get anime by slug
// @access  Public
router.get('/:slug', asyncHandler(async (req, res) => {
  const { slug } = req.params;
  
  const anime = await Anime.findOne({ slug })
    .populate('genres', 'name color')
    .populate('studio', 'name founded_year')
    .populate('season', 'name year season_type');

  if (!anime) {
    return res.status(404).json({
      success: false,
      message: 'Anime not found'
    });
  }

  // Increment view count
  anime.view_count += 1;
  await anime.save();

  // Get episodes count
  const episodesCount = await Episode.countDocuments({ anime: anime._id });

  res.json({
    success: true,
    message: 'Anime retrieved successfully',
    data: {
      ...anime.toObject(),
      episodes_count: episodesCount
    }
  });
}));

// @route   POST /api/v1/anime
// @desc    Create new anime (Admin only)
// @access  Private/Admin
router.post('/', asyncHandler(async (req, res) => {
  const animeData = req.body;

  // Validate required fields
  if (!animeData.title || !animeData.slug) {
    return res.status(400).json({
      success: false,
      message: 'Title and slug are required'
    });
  }

  // Check if anime with same slug exists
  const existingAnime = await Anime.findOne({ slug: animeData.slug });
  if (existingAnime) {
    return res.status(400).json({
      success: false,
      message: 'Anime with this slug already exists'
    });
  }

  const anime = new Anime(animeData);
  await anime.save();

  res.status(201).json({
    success: true,
    message: 'Anime created successfully',
    data: anime
  });
}));

// @route   PUT /api/v1/anime/:id
// @desc    Update anime (Admin only)
// @access  Private/Admin
router.put('/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;
  const updateData = req.body;

  const anime = await Anime.findByIdAndUpdate(
    id,
    updateData,
    { new: true, runValidators: true }
  );

  if (!anime) {
    return res.status(404).json({
      success: false,
      message: 'Anime not found'
    });
  }

  res.json({
    success: true,
    message: 'Anime updated successfully',
    data: anime
  });
}));

// @route   DELETE /api/v1/anime/:id
// @desc    Delete anime (Admin only)
// @access  Private/Admin
router.delete('/:id', asyncHandler(async (req, res) => {
  const { id } = req.params;

  const anime = await Anime.findByIdAndDelete(id);

  if (!anime) {
    return res.status(404).json({
      success: false,
      message: 'Anime not found'
    });
  }

  // Delete related episodes
  await Episode.deleteMany({ anime: id });

  res.json({
    success: true,
    message: 'Anime deleted successfully'
  });
}));

export default router;