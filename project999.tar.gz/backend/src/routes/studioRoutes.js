import express from 'express';

const router = express.Router();

// Mock studios data
const studios = [
  { id: '1', name: 'Mappa', description: 'Japanese animation studio', founded_year: 2011, website: 'https://mappa.co.jp' },
  { id: '2', name: 'Ufotable', description: 'Japanese animation studio', founded_year: 2000, website: 'https://ufotable.com' },
  { id: '3', name: 'Toei Animation', description: 'Japanese animation studio', founded_year: 1948, website: 'https://toei-anim.co.jp' },
  { id: '4', name: 'Pierrot', description: 'Japanese animation studio', founded_year: 1979, website: 'https://pierrot.jp' },
  { id: '5', name: 'Bones', description: 'Japanese animation studio', founded_year: 1998, website: 'https://bones.co.jp' }
];

// @route   GET /api/v1/studios
// @desc    Get all studios
// @access  Public
router.get('/', async (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Studios retrieved successfully',
      data: studios,
      count: studios.length
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   GET /api/v1/studios/:id
// @desc    Get studio by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const studio = studios.find(s => s.id === id);

    if (!studio) {
      return res.status(404).json({
        success: false,
        message: 'Studio not found'
      });
    }

    res.json({
      success: true,
      message: 'Studio retrieved successfully',
      data: studio
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

export default router;