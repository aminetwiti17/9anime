import express from 'express';

const router = express.Router();

// Mock comments data
const comments = [];

// @route   GET /api/v1/comments/anime/:animeId
// @desc    Get comments for anime
// @access  Public
router.get('/anime/:animeId', async (req, res) => {
  try {
    const { animeId } = req.params;
    const { page = 1, limit = 20 } = req.query;

    const animeComments = comments
      .filter(c => c.anime_id === animeId && c.is_approved)
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedComments = animeComments.slice(startIndex, endIndex);

    res.json({
      success: true,
      message: 'Comments retrieved successfully',
      data: paginatedComments,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: animeComments.length,
        total_pages: Math.ceil(animeComments.length / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   POST /api/v1/comments
// @desc    Create new comment
// @access  Private
router.post('/', async (req, res) => {
  try {
    const { anime_id, episode_id, content, is_spoiler = false } = req.body;

    if (!content || content.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Comment content is required'
      });
    }

    const newComment = {
      id: Date.now().toString(),
      user_id: '1', // In production, get from JWT
      anime_id,
      episode_id,
      parent_id: null,
      content: content.trim(),
      is_spoiler,
      is_approved: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user: {
        id: '1',
        username: 'testuser',
        avatar_url: null
      }
    };

    comments.push(newComment);

    res.status(201).json({
      success: true,
      message: 'Comment created successfully',
      data: newComment
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

export default router;