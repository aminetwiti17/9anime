import express from 'express';

const router = express.Router();

// @route   GET /api/v1/admin/dashboard
// @desc    Get admin dashboard data
// @access  Private/Admin
router.get('/dashboard', async (req, res) => {
  try {
    const dashboardData = {
      stats: {
        total_users: 25000,
        total_anime: 500,
        total_episodes: 12000,
        total_views: 1500000
      },
      recent_activity: [
        {
          type: 'new_user',
          message: 'New user registered: testuser',
          timestamp: new Date().toISOString()
        },
        {
          type: 'new_anime',
          message: 'New anime added: Test Anime',
          timestamp: new Date().toISOString()
        }
      ]
    };

    res.json({
      success: true,
      message: 'Dashboard data retrieved successfully',
      data: dashboardData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

// @route   GET /api/v1/admin/users
// @desc    Get all users (Admin only)
// @access  Private/Admin
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;

    const mockUsers = [
      {
        id: '1',
        email: 'user@example.com',
        username: 'testuser',
        created_at: '2024-01-01T00:00:00Z',
        is_active: true,
        role: 'user'
      }
    ];

    res.json({
      success: true,
      message: 'Users retrieved successfully',
      data: mockUsers,
      pagination: {
        current_page: parseInt(page),
        per_page: parseInt(limit),
        total: mockUsers.length,
        total_pages: Math.ceil(mockUsers.length / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
});

export default router;