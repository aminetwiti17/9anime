// Script d'initialisation MongoDB pour AniStream
// Ce script s'exécute automatiquement lors du premier démarrage du conteneur MongoDB

db = db.getSiblingDB('anistream_db');

// Créer les collections avec validation
db.createCollection('users', {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["email", "username", "password"],
      properties: {
        email: {
          bsonType: "string",
          pattern: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
        },
        username: {
          bsonType: "string",
          minLength: 3,
          maxLength: 50
        },
        password: {
          bsonType: "string",
          minLength: 6
        }
      }
    }
  }
});

db.createCollection('anime', {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["title", "slug"],
      properties: {
        title: {
          bsonType: "string",
          maxLength: 255
        },
        slug: {
          bsonType: "string"
        },
        rating: {
          bsonType: "number",
          minimum: 0,
          maximum: 10
        }
      }
    }
  }
});

db.createCollection('episodes');
db.createCollection('genres');
db.createCollection('studios');
db.createCollection('seasons');
db.createCollection('comments');
db.createCollection('user_watchlists');
db.createCollection('user_watch_history');

// Créer les index pour optimiser les performances
db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "username": 1 }, { unique: true });

db.anime.createIndex({ "slug": 1 }, { unique: true });
db.anime.createIndex({ "status": 1 });
db.anime.createIndex({ "anime_type": 1 });
db.anime.createIndex({ "rating": -1 });
db.anime.createIndex({ "view_count": -1 });
db.anime.createIndex({ "is_trending": 1 });
db.anime.createIndex({ "is_featured": 1 });
db.anime.createIndex({ "release_year": -1 });

db.episodes.createIndex({ "anime_id": 1, "episode_number": 1 }, { unique: true });
db.episodes.createIndex({ "anime_id": 1 });
db.episodes.createIndex({ "air_date": -1 });

db.genres.createIndex({ "name": 1 }, { unique: true });
db.studios.createIndex({ "name": 1 }, { unique: true });

db.comments.createIndex({ "anime_id": 1 });
db.comments.createIndex({ "user_id": 1 });
db.comments.createIndex({ "created_at": -1 });

db.user_watchlists.createIndex({ "user_id": 1, "anime_id": 1 }, { unique: true });
db.user_watch_history.createIndex({ "user_id": 1, "anime_id": 1, "episode_id": 1 }, { unique: true });

// Insérer des données de base pour les genres
db.genres.insertMany([
  { name: "Action", description: "Anime with intense action sequences", color: "#ef4444" },
  { name: "Adventure", description: "Journey and exploration themed anime", color: "#f59e0b" },
  { name: "Comedy", description: "Humorous and light-hearted anime", color: "#10b981" },
  { name: "Drama", description: "Serious and emotional storytelling", color: "#8b5cf6" },
  { name: "Fantasy", description: "Supernatural and magical elements", color: "#06b6d4" },
  { name: "Horror", description: "Scary and suspenseful content", color: "#dc2626" },
  { name: "Mystery", description: "Puzzle-solving and detective stories", color: "#7c3aed" },
  { name: "Romance", description: "Love and relationship stories", color: "#ec4899" },
  { name: "Sci-Fi", description: "Science fiction and futuristic themes", color: "#6366f1" },
  { name: "Slice of Life", description: "Everyday life and realistic situations", color: "#84cc16" },
  { name: "Sports", description: "Athletic and competitive themes", color: "#f97316" },
  { name: "Supernatural", description: "Paranormal and mystical elements", color: "#a855f7" },
  { name: "Thriller", description: "Suspenseful and intense narratives", color: "#64748b" }
]);

// Insérer des données de base pour les studios
db.studios.insertMany([
  { name: "MAPPA", description: "Modern Animation Planning Project", founded_year: 2011 },
  { name: "Studio Ghibli", description: "Famous animation studio", founded_year: 1985 },
  { name: "Bones", description: "Bones Inc.", founded_year: 1998 },
  { name: "Madhouse", description: "Madhouse Inc.", founded_year: 1972 },
  { name: "A-1 Pictures", description: "A-1 Pictures Inc.", founded_year: 2005 },
  { name: "Production I.G", description: "Production I.G Inc.", founded_year: 1987 },
  { name: "Kyoto Animation", description: "Kyoto Animation Co., Ltd.", founded_year: 1981 },
  { name: "Trigger", description: "Studio Trigger", founded_year: 2011 }
]);

print("✅ MongoDB initialization completed successfully!");
print("📊 Database: anistream_db");
print("📚 Collections created with validation and indexes");
print("🎨 Base genres and studios inserted"); 