# AniStream Backend API

Backend Node.js complet pour la plateforme de streaming anime AniStream avec MongoDB.

## 🚀 Fonctionnalités

### 🎬 Gestion des Anime
- CRUD complet des anime avec validation
- Système de recherche avancée avec filtres
- Gestion des genres, studios, saisons
- Système de recommandations IA
- Compteur de vues et analytics

### 📺 Gestion des Épisodes
- Multi-serveurs vidéo par épisode
- Qualités multiples (360p à 4K)
- Support SUB/DUB
- Système de bookmarks
- Transcoding automatique

### 👥 Gestion Utilisateurs
- Authentification JWT sécurisée
- Rôles (user, moderator, admin)
- Watchlists personnalisées
- Historique de visionnage
- Système de notation

### 💬 Système Social
- Commentaires avec modération
- Système de likes/dislikes
- Notifications en temps réel
- Signalement de contenu

## 🛠️ Installation

### Prérequis
- Node.js 18+
- MongoDB 6+
- Redis 6+
- Docker (optionnel)

### Installation avec Docker (Recommandé)

1. **Cloner le projet**
```bash
git clone <repository>
cd backend
```

2. **Démarrer les services avec Docker**
```bash
docker-compose up -d
```

3. **Installer les dépendances**
```bash
npm install
```

4. **Configurer l'environnement**
```bash
cp .env.example .env
# Éditer .env avec vos configurations
```

5. **Exécuter les migrations et seeds**
```bash
npm run migrate
npm run seed
```

6. **Démarrer le serveur**
```bash
npm run dev
```

### Installation manuelle

1. **Installer MongoDB et Redis**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install mongodb redis-server

# macOS avec Homebrew
brew install mongodb/brew/mongodb-community redis

# Windows
# Télécharger depuis les sites officiels
```

2. **Démarrer MongoDB**
```bash
# Ubuntu/Debian
sudo systemctl start mongod
sudo systemctl enable mongod

# macOS
brew services start mongodb/brew/mongodb-community

# Windows
# Démarrer le service MongoDB
```

3. **Démarrer Redis**
```bash
# Ubuntu/Debian
sudo systemctl start redis-server
sudo systemctl enable redis-server

# macOS
brew services start redis

# Windows
# Démarrer le service Redis
```

4. **Suivre les étapes 3-6 de l'installation Docker**

## 📋 Scripts disponibles

```bash
# Développement
npm run dev          # Démarrer en mode développement avec nodemon
npm start           # Démarrer en mode production

# Base de données
npm run migrate     # Exécuter les migrations MongoDB
npm run seed        # Exécuter les seeds
npm run db:reset    # Réinitialiser la base de données
npm run db:setup    # Migrations + Seeds

# Tests
npm test           # Exécuter les tests
npm run test:watch # Tests en mode watch

# Build
npm run build      # Préparer pour la production
```

## 🔧 Configuration

### Variables d'environnement

Copiez `.env.example` vers `.env` et configurez:

```env
# MongoDB
MONGODB_URI=mongodb://admin:admin123456@localhost:27017/anistream_db?authSource=admin

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT
JWT_SECRET=your_super_secret_key
JWT_EXPIRE=7d

# Email (optionnel)
SMTP_HOST=smtp.gmail.com
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
```

### Configuration MongoDB

1. **Créer la base de données**
```bash
# Se connecter à MongoDB
mongosh

# Créer la base de données
use anistream_db

# Créer un utilisateur admin
db.createUser({
  user: "admin",
  pwd: "admin123456",
  roles: ["readWrite", "dbAdmin"]
})
```

2. **Configuration de sécurité**
```bash
# Éditer /etc/mongod.conf
sudo nano /etc/mongod.conf

# Activer l'authentification
security:
  authorization: enabled

# Redémarrer MongoDB
sudo systemctl restart mongod
```

### Configuration Redis

Redis fonctionne avec la configuration par défaut. Pour la production:

```bash
# Éditer /etc/redis/redis.conf
sudo nano /etc/redis/redis.conf

# Configurer un mot de passe
requirepass your_redis_password

# Redémarrer Redis
sudo systemctl restart redis-server
```

## 📚 API Documentation

Une fois le serveur démarré, accédez à la documentation Swagger:

```
http://localhost:5000/api-docs
```

### Endpoints principaux

#### Authentification
```
POST /api/v1/auth/register    # Inscription
POST /api/v1/auth/login       # Connexion
POST /api/v1/auth/refresh     # Rafraîchir le token
```

#### Anime
```
GET    /api/v1/anime          # Liste des anime
GET    /api/v1/anime/trending # Anime tendance
GET    /api/v1/anime/:id      # Détails d'un anime
POST   /api/v1/anime          # Créer un anime (Admin)
PUT    /api/v1/anime/:id      # Modifier un anime (Admin)
DELETE /api/v1/anime/:id      # Supprimer un anime (Admin)
```

#### Épisodes
```
GET /api/v1/episodes/:id      # Détails d'un épisode
GET /api/v1/anime/:id/episodes # Épisodes d'un anime
```

#### Utilisateurs
```
GET    /api/v1/users/profile     # Profil utilisateur
PUT    /api/v1/users/profile     # Modifier le profil
GET    /api/v1/users/watchlist   # Watchlist
POST   /api/v1/anime/:id/watchlist # Ajouter à la watchlist
```

## 🗄️ Structure de la base de données

### Collections principales

- **users** - Utilisateurs
- **anime** - Anime
- **episodes** - Épisodes
- **genres** - Genres
- **studios** - Studios d'animation
- **seasons** - Saisons
- **comments** - Commentaires
- **user_watchlists** - Watchlists
- **user_watch_history** - Historique de visionnage

### Relations MongoDB

```
users (1) ←→ (n) user_watchlists ←→ (1) anime
users (1) ←→ (n) user_watch_history ←→ (1) anime
users (1) ←→ (n) comments ←→ (1) anime
anime (1) ←→ (n) episodes
anime (n) ←→ (n) genres (via array)
anime (n) ←→ (1) studios
anime (n) ←→ (1) seasons
```

## 🔒 Sécurité

### Authentification
- JWT avec expiration
- Refresh tokens
- Hashage bcrypt des mots de passe
- Rate limiting par IP

### Autorisation
- Rôles utilisateur (user, moderator, admin)
- Middleware de vérification des permissions
- Validation stricte des données

### Protection
- Helmet.js pour les en-têtes de sécurité
- CORS configuré
- Validation des données avec Joi
- Sanitisation des entrées

## 🚀 Déploiement

### Avec Docker

```bash
# Build l'image
docker build -t anistream-backend .

# Démarrer les services
docker-compose up -d

# Vérifier les logs
docker-compose logs -f
```

### Production

```bash
# Installer les dépendances de production
npm ci --only=production

# Démarrer le serveur
npm start
```

## 📊 Monitoring

### Health Check
```
GET /health
```

### Métriques MongoDB
```bash
# Se connecter à MongoDB
mongosh

# Vérifier les statistiques
db.stats()

# Vérifier les collections
show collections
```

## 🔧 Outils d'administration

### MongoDB Express
Accédez à l'interface web MongoDB Express:
```
http://localhost:8080
```

### Redis Commander
Accédez à l'interface web Redis Commander:
```
http://localhost:8081
```

## 🐛 Dépannage

### Problèmes de connexion MongoDB
```bash
# Vérifier le statut MongoDB
sudo systemctl status mongod

# Vérifier les logs
sudo journalctl -u mongod -f

# Tester la connexion
mongosh --host localhost --port 27017
```

### Problèmes de performance
```bash
# Vérifier les index MongoDB
mongosh
use anistream_db
db.anime.getIndexes()
```

## 📝 Logs

Les logs sont gérés par Winston et peuvent être configurés dans `src/config/logger.js`.

## 🤝 Contribution

1. Fork le projet
2. Créer une branche feature (`git checkout -b feature/AmazingFeature`)
3. Commit les changements (`git commit -m 'Add some AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request